import React, { useState, useEffect } from 'react';
import {
  Page,
  Card,
  FormLayout,
  TextField,
  Select,
  Button,
  BlockStack,
  InlineStack,
  Text,
  Checkbox,
} from '@shopify/polaris';
import { useParams, useNavigate } from 'react-router-dom';

function FeedEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = !id;

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [ftpConnections, setFtpConnections] = useState([]);

  const [formData, setFormData] = useState({
    name: '',
    ftpConnection: '',
    file: {
      path: '',
      delimiter: ',',
      encoding: 'utf8',
      hasHeader: true,
    },
    matching: {
      column: '',
      type: 'sku',
    },
    mappings: [],
    schedule: {
      enabled: false,
      frequency: 'daily',
      time: '00:00',
    },
    options: {
      skipUnchangedFile: true,
      createMissingMetafields: true,
      updateExisting: true,
      createNew: true,
    },
  });

  useEffect(() => {
    fetchFtpConnections();
    if (!isNew) {
      fetchFeed();
    }
  }, [id]);

  const fetchFtpConnections = async () => {
    try {
      const shop = new URLSearchParams(window.location.search).get('shop') || 'dev-shop.myshopify.com';
      const response = await fetch(`/api/ftp-connections?shop=${shop}`);
      const data = await response.json();
      setFtpConnections(data.connections);
    } catch (error) {
      console.error('Error fetching FTP connections:', error);
    }
  };

  const fetchFeed = async () => {
    setLoading(true);
    try {
      const shop = new URLSearchParams(window.location.search).get('shop') || 'dev-shop.myshopify.com';
      const response = await fetch(`/api/feeds/${id}?shop=${shop}`);
      const data = await response.json();
      setFormData({
        ...data.feed,
        ftpConnection: data.feed.ftpConnection._id,
      });
    } catch (error) {
      console.error('Error fetching feed:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    setSaving(true);
    try {
      const shop = new URLSearchParams(window.location.search).get('shop') || 'dev-shop.myshopify.com';
      const url = isNew
        ? `/api/feeds?shop=${shop}`
        : `/api/feeds/${id}?shop=${shop}`;

      const response = await fetch(url, {
        method: isNew ? 'POST' : 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const data = await response.json();
        navigate(`/feeds/${data.feed._id}`);
      } else {
        alert('Error saving feed');
      }
    } catch (error) {
      console.error('Error saving feed:', error);
      alert('Error saving feed');
    } finally {
      setSaving(false);
    }
  };

  const ftpOptions = ftpConnections.map((conn) => ({
    label: conn.name,
    value: conn._id,
  }));

  return (
    <Page
      title={isNew ? 'Create Feed' : 'Edit Feed'}
      backAction={{ onAction: () => navigate('/feeds') }}
    >
      <Card>
        <BlockStack gap="400">
          <FormLayout>
            <TextField
              label="Feed Name"
              value={formData.name}
              onChange={(value) =>
                setFormData({ ...formData, name: value })
              }
              autoComplete="off"
            />

            <Select
              label="FTP Connection"
              options={ftpOptions}
              value={formData.ftpConnection}
              onChange={(value) =>
                setFormData({ ...formData, ftpConnection: value })
              }
            />

            <TextField
              label="CSV File Path"
              value={formData.file.path}
              onChange={(value) =>
                setFormData({
                  ...formData,
                  file: { ...formData.file, path: value },
                })
              }
              helpText="Path relative to FTP root directory"
              autoComplete="off"
            />

            <Select
              label="Delimiter"
              options={[
                { label: 'Comma (,)', value: ',' },
                { label: 'Semicolon (;)', value: ';' },
                { label: 'Tab', value: '\t' },
                { label: 'Pipe (|)', value: '|' },
              ]}
              value={formData.file.delimiter}
              onChange={(value) =>
                setFormData({
                  ...formData,
                  file: { ...formData.file, delimiter: value },
                })
              }
            />

            <TextField
              label="Matching Column"
              value={formData.matching.column}
              onChange={(value) =>
                setFormData({
                  ...formData,
                  matching: { ...formData.matching, column: value },
                })
              }
              helpText="CSV column name to match products"
              autoComplete="off"
            />

            <Select
              label="Matching Type"
              options={[
                { label: 'SKU', value: 'sku' },
                { label: 'Handle', value: 'handle' },
              ]}
              value={formData.matching.type}
              onChange={(value) =>
                setFormData({
                  ...formData,
                  matching: { ...formData.matching, type: value },
                })
              }
            />

            <Checkbox
              label="Enable Scheduling"
              checked={formData.schedule.enabled}
              onChange={(value) =>
                setFormData({
                  ...formData,
                  schedule: { ...formData.schedule, enabled: value },
                })
              }
            />

            {formData.schedule.enabled && (
              <>
                <Select
                  label="Frequency"
                  options={[
                    { label: 'Hourly', value: 'hourly' },
                    { label: 'Every 6 Hours', value: 'every_6_hours' },
                    { label: 'Daily', value: 'daily' },
                    { label: 'Weekly', value: 'weekly' },
                  ]}
                  value={formData.schedule.frequency}
                  onChange={(value) =>
                    setFormData({
                      ...formData,
                      schedule: { ...formData.schedule, frequency: value },
                    })
                  }
                />

                <TextField
                  label="Time (HH:mm)"
                  value={formData.schedule.time}
                  onChange={(value) =>
                    setFormData({
                      ...formData,
                      schedule: { ...formData.schedule, time: value },
                    })
                  }
                  autoComplete="off"
                />
              </>
            )}

            <Text variant="headingMd">Options</Text>

            <Checkbox
              label="Skip unchanged file (based on checksum)"
              checked={formData.options.skipUnchangedFile}
              onChange={(value) =>
                setFormData({
                  ...formData,
                  options: { ...formData.options, skipUnchangedFile: value },
                })
              }
            />

            <Checkbox
              label="Create missing metafields automatically"
              checked={formData.options.createMissingMetafields}
              onChange={(value) =>
                setFormData({
                  ...formData,
                  options: {
                    ...formData.options,
                    createMissingMetafields: value,
                  },
                })
              }
            />

            <Checkbox
              label="Update existing products"
              checked={formData.options.updateExisting}
              onChange={(value) =>
                setFormData({
                  ...formData,
                  options: { ...formData.options, updateExisting: value },
                })
              }
            />

            <Checkbox
              label="Create new products"
              checked={formData.options.createNew}
              onChange={(value) =>
                setFormData({
                  ...formData,
                  options: { ...formData.options, createNew: value },
                })
              }
            />
          </FormLayout>

          <InlineStack align="end" gap="200">
            <Button onClick={() => navigate('/feeds')}>Cancel</Button>
            <Button
              variant="primary"
              onClick={handleSubmit}
              loading={saving}
            >
              {isNew ? 'Create Feed' : 'Save Changes'}
            </Button>
          </InlineStack>
        </BlockStack>
      </Card>
    </Page>
  );
}

export default FeedEdit;
